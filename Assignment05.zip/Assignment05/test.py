dictRow = {}

while(True):
    add = str(input("What would you like to add to the dictionary [key, value]: "))
    split = add.split(",")
    tpSplit = tuple(split)
    dictRow[tpSplit[0]] = tpSplit[1]
    print(dictRow)